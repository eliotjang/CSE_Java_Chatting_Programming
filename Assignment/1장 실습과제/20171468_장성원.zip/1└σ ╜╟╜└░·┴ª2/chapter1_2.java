/* 2019.09.08 
 * eliotjang */
package chapter1;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
class chapter1_2 extends Frame implements ActionListener {
	//static int count = 0;
	int bytesRead;
	Label linput, loutput, lfile;
	TextField tinput, toutput;
	TextArea tadata;
	Button iconfirm, oconfirm;
	String filename1, filename2;
	byte[] buffer = new byte[256];
	FileInputStream fin = null;
	FileOutputStream fout = null;
	
	public chapter1_2(String str) {
		super(str); // ������ü ����
		setLayout(new FlowLayout()); //��ü�� ������ ������� ��ġ
		linput = new Label("�Է�����");
		add(linput);
		tinput = new TextField(10);
		add(tinput);
		Button iconfirm = new Button("Ȯ��");
		iconfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					filename1 = tinput.getText();
					fin = new FileInputStream(filename1);
				}catch(IOException e) {
					System.out.println(e.toString());
				}
			}
		}); //�̺�Ʈ ���.
		add(iconfirm);
		loutput = new Label("�������");
		add(loutput);
		toutput = new TextField(10);
		add(toutput);
		Button oconfirm = new Button("Ȯ��");
		oconfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					filename2 = toutput.getText();
					fout = new FileOutputStream(filename2);
					while((bytesRead = fin.read(buffer)) >= 0) {
						fout.write(buffer, 0, bytesRead);
						String data = new String(buffer);
						tadata.setText(data+"\n");
					}
					}catch(IOException e) {
						System.out.println(e.toString());
					}finally {
						try {
							if(fin != null) fin.close();
							if(fout != null) fout.close();
						}catch(IOException e) {}
					}
				}
		}); //�̺�Ʈ ���.
		add(oconfirm);
		lfile = new Label("���ϳ���");
		add(lfile);
		tadata = new TextArea(9, 34);
		add(tadata);
		addWindowListener(new WinListener());
		
	}
	public static void main(String[] args) {
		chapter1_2 text = new chapter1_2("");
		text.setSize(270,300);
		text.setVisible(true);
		
	}
	/*public void actionPerformed(ActionEvent ae) {
		count += 1;
		if (count == 1) { 
			try {
				filename1 = tinput.getText();
				fin = new FileInputStream(filename1);
			}catch(IOException e) {
				System.out.println(e.toString());
			}
		}
		else if (count == 2) {
			try {
			filename2 = toutput.getText();
			fout = new FileOutputStream(filename2);
			while((bytesRead = fin.read(buffer)) >= 0) {
				fout.write(buffer, 0, bytesRead);
				String data = new String(buffer);
				tadata.setText(data+"\n");
			}
			}catch(IOException e) {
				System.out.println(e.toString());
			}finally {
				try {
					if(fin != null) fin.close();
					if(fout != null) fout.close();
				}catch(IOException e) {}
			}
		}
		else {System.err.println("�̺�Ʈ ���� �߻�");}
	}*/
	class WinListener extends WindowAdapter{
		public void windowClosing(WindowEvent we) {
			System.exit(0);
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
