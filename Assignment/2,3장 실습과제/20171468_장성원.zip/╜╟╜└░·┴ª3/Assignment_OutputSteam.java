// updated 2019.09.22
// coded by eliotjang
package chapter2;

import java.io.*;
/*import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;*/

class Assignment_OutputStream extends FilterOutputStream {

  private OutputStream out1;
  private OutputStream out2;

  public Assignment_OutputStream(OutputStream s1, OutputStream s2) {
    super(s1); //���� ��ü ����. ������ �θ� Ŭ������ �����ڱ��� �ʱ�ȭ.
    out1 = s1;
    out2 = s2;
  }

  public void write(int b) throws IOException {
    out1.write(b);
    out2.write(b);
  }

  public void write(byte[] data, int offset, int length) throws IOException {
    out1.write(data, offset, length);
    out2.write(data, offset, length);
  }

  public void flush() throws IOException {
    out1.flush();
    out2.flush();
  }

  public void close() throws IOException {
    out1.close();
    out2.close();
  }
}