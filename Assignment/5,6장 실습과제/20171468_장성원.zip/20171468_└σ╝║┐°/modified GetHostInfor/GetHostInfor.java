/*
 * author: eliotjang
 * last_modified_at: 2019-10-14T22:08:00+09:00
 */

package chapter5;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class GetHostInfor extends Frame implements ActionListener {
	TextField hostname, viewclass;
	Button getinfor;
	TextArea display;

	public static void main(String[] args) {
		GetHostInfor host = new GetHostInfor("InetAddress Ŭ����");
		host.setVisible(true);
	}
	
	public GetHostInfor(String str) {
		super(str);
		addWindowListener(new WinListener());
		setLayout(new BorderLayout());
		Panel inputpanel = new Panel();
		inputpanel.setLayout(new BorderLayout());
		inputpanel.add("North", new Label("ȣ��Ʈ �̸�:"));
		hostname = new TextField("", 30);
		getinfor = new Button("ȣ��Ʈ ���� ���");
		inputpanel.add("Center", hostname);
		inputpanel.add("South", getinfor);
		getinfor.addActionListener(this);
		add("North", inputpanel);
		
		Panel outputpanel = new Panel();
		outputpanel.setLayout(new BorderLayout());
		display = new TextArea("", 24, 40);
		display.setEditable(false);
		outputpanel.add("North", new Label("���ͳ� �ּ�"));
		outputpanel.add("Center", display);
		add("Center", outputpanel);
		
		Panel classpanel = new Panel();
		classpanel.setLayout(new BorderLayout());
		viewclass = new TextField("", 30);
		viewclass.setEditable(false);
		classpanel.add("North", new Label("Ŭ���� ����"));
		classpanel.add("Center", viewclass);
		add("South", classpanel);
		
		setLocationRelativeTo(null); // GUI�� ����� �߾ӿ� ��ġ
		setSize(400, 400);
	}
	
	public void actionPerformed(ActionEvent e) {
		String name = hostname.getText();
		try {
			InetAddress[] inet = InetAddress.getAllByName(name);
			InetAddress maininet = InetAddress.getByName(name);
			for ( int i=0 ; i < inet.length ; i++) {
				display.append(inet[i].toString()+"\n");
			}		
			char result = ipClass(maininet.getAddress());
			viewclass.setText(Character.toString(result));
		} catch(UnknownHostException ue) {
			String ip = name+": �ش� ȣ��Ʈ�� �����ϴ�.\n";
			display.append(ip);
		}
	}
	
	static char ipClass(byte[] ip) {
		int highByte = 0xff & ip[0];
		return(highByte < 128 ? 'A' : highByte < 192 ? 'B' : highByte < 224 ? 'C' : highByte < 240 ? 'D' : 'E');
		/*
		 * NetWorkAddress of highByte
		 * A: 0~126, B: 128~191, C: 192~223, D: 224~239, E: 240~255
		 */
	}
	
	class WinListener extends WindowAdapter {
		
		public void windowClosing(WindowEvent we) {
			System.exit(0);
		}
	}

}
